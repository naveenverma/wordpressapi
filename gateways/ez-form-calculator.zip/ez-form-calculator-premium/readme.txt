Hello!

Thank you for purchasing ez Form Calculator WordPress plugin.

In order to get started visit the documentation online:
http://ez-form-calculator.ezplugins.de/documentation/

For bug reports and further help, please write a detailed email to:
support@ezplugins.de

Otherwise, you can visit my profile on CodeCanyon and drop me a line there:
http://codecanyon.net/user/keksdieb

If you are satisfied with the product, do not forget to rate!


Best regards
Michael
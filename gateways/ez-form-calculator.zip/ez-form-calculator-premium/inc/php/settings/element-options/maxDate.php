<?php

/**
 * maxDate element option
 */
class Ezfc_Settings_Element_Option_maxDate extends Ezfc_Settings_Element_Option_minDate {
	public $name = "maxDate";
}
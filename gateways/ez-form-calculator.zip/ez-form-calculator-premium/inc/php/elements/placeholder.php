<?php

class Ezfc_Element_Placeholder extends Ezfc_Element_Decor {
	public function get_output() {
		return "";
	}

	public function get_label() {
		return "";
	}
}
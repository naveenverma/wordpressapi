<?php

/**
	Decoration element
**/
class Ezfc_Element_Decor extends Ezfc_Element {
	public function get_test_value() {
		return "";
	}
}